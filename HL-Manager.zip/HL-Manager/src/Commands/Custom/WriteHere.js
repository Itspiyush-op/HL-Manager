const { ChannelType, ApplicationCommandOptionType } = require("discord.js");
const { MainClient, Context, Commands } = require("../../Structures/index.js");

class WriteHere extends Commands {
  constructor(client) {
    super(client, {
      name: "writehere",
      description:
        "Allows a user permission to send messages for  20 seconds.",
      usage: "writehere <@user> [#channel]",
      aliases: ["wh"],
      cooldown: 5,
      category: "Custom",
      args: true,
      slash: true,
      options: [
        {
          name: "user",
          description: "Select a user",
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: "channel",
          description: "Select a channel",
          type: ApplicationCommandOptionType.Channel,
          channel_types: [ChannelType.GuildText],
          required: false,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: ["ManageChannels"],
      botPermissions: ["ManageChannels"],
    });
  }
  /**
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx, args) {
    let user;
    let channel;

    if (ctx.isInteraction) {
      user = ctx.interaction.options.getMember("user") || ctx.author;
      channel = ctx.interaction.options.getChannel("channnel") || ctx.channel;
    } else {
      user =
        ctx.message.mentions.users.first() ||
        (await ctx.guild.members.cache.get(args[0]).catch((_) => null));
      channel =
        ctx.message.mentions.channels.first() ||
        (await ctx.guild.channels.cache.get(args[1]));
    }
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    if (!user)
      return await ctx.sendMessage({
        embeds: [
          embed
            .setColor("Red")
            .setDescription(`${client.config.emoji.cross} | User not found!`),
        ],
      });

    if (!channel) channel = ctx.channel;

    try {
      await channel.permissionOverwrites.edit(user.id, { SendMessages: true });
      await ctx.sendMessage({
        embeds: [
          embed.setDescription(
            `${client.config.emoji.tick} | Successfully Added **WriteHere** Permission For 20 Seconds!`
          ),
        ],
      });
      setTimeout(async () => {
        await channel.permissionOverwrites.delete(user.id);
        await ctx.sendFollowUp({
          embeds: [
            embed.setDescription(
              `${client.config.emoji.tick} | Successfully Removed **WriteHere** Permission From <@${user.id}>!`
            ),
          ],
        });
      }, 20 * 1000);
    } catch (error) {
      console.error(error);
      client.logger.error(`Unable to execute writehere command!`);
    }
  }
}

module.exports = WriteHere;
