const {
  ApplicationCommandOptionType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const { MainClient, Commands, Context } = require("../../Structures/index.js");

class Flags extends Commands {
  constructor(client) {
    super(client, {
      name: "flags",
      description: "Start the flag-rolling game!",
      usage: "flags <flag-emoji>",
      cooldown: 60,
      aliases: [],
      category: "Custom",
      args: true,
      slash: true,
      options: [
        {
          name: "flag",
          description: "Select a flag emoji to roll for.",
          type: ApplicationCommandOptionType.String,
          required: true,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: ["ManageMessages"],
      botPermissions: ["ManageMessages"],
    });
  }
  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx, args) {
    let selectedFlag = ctx.interaction
      ? ctx.interaction.options.getString("flag")
      : args[0];

    let flagEmojis = [
      "🇦🇫",
      "🇦🇱",
      "🇩🇿",
      "🇦🇸",
      "🇦🇩",
      "🇦🇴",
      "🇦🇮",
      "🇦🇶",
      "🇦🇬",
      "🇦🇷",
      "🇦🇲",
      "🇦🇺",
      "🇦🇹",
      "🇦🇿",
      "🇧🇸",
      "🇧🇭",
      "🇧🇩",
      "🇧🇧",
      "🇧🇾",
      "🇧🇪",
      "🇧🇿",
      "🇧🇯",
      "🇧🇲",
      "🇧🇹",
      "🇧🇴",
      "🇧🇦",
      "🇧🇼",
      "🇧🇷",
      "🇮🇴",
      "🇧🇳",
      "🇧🇬",
      "🇧🇫",
      "🇧🇮",
      "🇨🇻",
      "🇰🇭",
      "🇨🇲",
      "🇨🇦",
      "🇨🇫",
      "🇹🇩",
      "🇨🇱",
      "🇨🇳",
      "🇨🇴",
      "🇰🇲",
      "🇨🇩",
      "🇨🇷",
      "🇭🇷",
      "🇨🇺",
      "🇨🇾",
      "🇨🇿",
      "🇩🇰",
      "🇩🇯",
      "🇩🇲",
      "🇩🇴",
      "🇪🇨",
      "🇪🇬",
      "🇸🇻",
      "🇬🇶",
      "🇪🇷",
      "🇪🇪",
      "🇪🇹",
      "🇫🇯",
      "🇫🇮",
      "🇫🇷",
      "🇬🇦",
      "🇬🇲",
      "🇬🇪",
      "🇩🇪",
      "🇬🇭",
      "🇬🇷",
      "🇬🇩",
      "🇬🇹",
      "🇬🇳",
      "🇬🇼",
      "🇬🇾",
      "🇭🇹",
      "🇭🇳",
      "🇭🇰",
      "🇭🇺",
      "🇮🇸",
      "🇮🇳",
      "🇮🇩",
      "🇮🇷",
      "🇮🇶",
      "🇮🇪",
      "🇮🇱",
      "🇮🇹",
      "🇨🇮",
      "🇯🇲",
      "🇯🇵",
      "🇯🇴",
      "🇰🇿",
      "🇰🇪",
      "🇰🇮",
      "🇽🇰",
      "🇰🇼",
      "🇰🇬",
      "🇱🇦",
      "🇱🇻",
      "🇱🇧",
      "🇱🇸",
      "🇱🇷",
      "🇱🇾",
      "🇱🇮",
      "🇱🇹",
      "🇱🇺",
      "🇲🇴",
      "🇲🇰",
      "🇲🇬",
      "🇲🇼",
      "🇲🇾",
      "🇲🇻",
      "🇲🇱",
      "🇲🇹",
      "🇲🇭",
      "🇲🇶",
      "🇲🇷",
      "🇲🇺",
      "🇲🇽",
      "🇫🇲",
      "🇲🇩",
      "🇲🇨",
      "🇲🇳",
      "🇲🇪",
      "🇲🇸",
      "🇲🇦",
      "🇲🇿",
      "🇲🇲",
      "🇳🇦",
      "🇳🇷",
      "🇳🇵",
      "🇳🇱",
      "🇳🇨",
      "🇳🇿",
      "🇳🇮",
      "🇳🇪",
      "🇳🇬",
      "🇳🇺",
      "🇲🇵",
      "🇰🇵",
      "🇳🇴",
      "🇴🇲",
      "🇵🇰",
      "🇵🇼",
      "🇵🇸",
      "🇵🇦",
      "🇵🇬",
      "🇵🇾",
      "🇵🇪",
      "🇵🇭",
      "🇵🇱",
      "🇵🇹",
      "🇵🇷",
      "🇶🇦",
      "🇷🇴",
      "🇷🇺",
      "🇷🇼",
      "🇰🇳",
      "🇱🇨",
      "🇻🇨",
      "🇼🇸",
      "🇸🇲",
      "🇸🇦",
      "🇸🇳",
      "🇷🇸",
      "🇸🇨",
      "🇸🇱",
      "🇸🇬",
      "🇸🇰",
      "🇸🇮",
      "🇸🇧",
      "🇸🇴",
      "🇿🇦",
      "🇰🇷",
      "🇸🇸",
      "🇪🇸",
      "🇱🇰",
      "🇸🇩",
      "🇸🇷",
      "🇸🇿",
      "🇸🇪",
      "🇨🇭",
      "🇸🇾",
      "🇹🇼",
      "🇹🇯",
      "🇹🇿",
      "🇹🇭",
      "🇹🇱",
      "🇹🇬",
      "🇹🇴",
      "🇹🇹",
      "🇹🇳",
      "🇹🇷",
      "🇹🇲",
      "🇹🇻",
      "🇺🇬",
      "🇺🇦",
      "🇦🇪",
      "🇬🇧",
      "🇺🇸",
      "🇺🇾",
      "🇺🇿",
      "🇻🇺",
      "🇻🇦",
      "🇻🇪",
      "🇻🇳",
      "🇾🇪",
      "🇿🇲",
      "🇿🇼",
    ];

    if (!flagEmojis.includes(selectedFlag)) {
      return await ctx
        .sendMessage({
          content: `${
            client.config.emoji.cross
          } | Invalid flag emoji! Please choose from: ${flagEmojis.join(" ")}`,
          ephemeral: true,
        })
        .then(async (m) => await ctx.deleteMessage(m, 10000));
    }

    let timestampNow = Math.floor(Date.now() / 1000);
    let timestampFiveMin = timestampNow + 300;

    let gameEmbed = client
      .embed()
      .setAuthor({
        name: `${ctx.author.displayName} Started the roll the flags game!`,
        iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
      })
      .setTitle("Roll The Flags")
      .setDescription("A new round has started! Try to roll the matching flag!")
      .addFields({
        name: "Flag To Find",
        value: `- ${selectedFlag}`,
        inline: true,
      })
      .addFields({
        name: "Time Remaining",
        value: `<t:${timestampFiveMin}:R>`,
        inline: true,
      })

      .setFooter({ text: "Click the button below to roll" })
      .setTimestamp();

    let row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("roll")
        .setLabel("🎲 Roll")
        .setStyle(ButtonStyle.Primary)
    );

    const message = await ctx.sendMessage({
      embeds: [gameEmbed],
      components: [row],
    });

    const collector = message.createMessageComponentCollector({
      time: 5 * 60 * 1000,
    });

    collector.on("collect", async (interaction) => {
      let rolledFlag =
        flagEmojis[Math.floor(Math.random() * flagEmojis.length)];

      if (rolledFlag === selectedFlag) {
        let winEmbed = client
          .embed()
          .setAuthor({
            name: `${ctx.author.displayName} Started the roll the flags game!`,
            iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
          })
          .setTitle("🎉 You Win!")
          .setDescription(
            `<@${interaction.user.id}> You rolled the correct flag: **${rolledFlag}**!`
          )
          .setColor("Green")
          .setFooter({ text: "Game Ended!" });
        await interaction.update({
          embeds: [winEmbed],
          components: [],
          ephemeral: false,
        });
        await interaction.reply({
          content: `🏆 **Winner:** <@${interaction.user.id}> 🏆\n
          You rolled **${rolledFlag}`,
        });
        collector.stop();
      } else {
        await interaction.reply({
          content: `You Rolled **${rolledFlag}**!`,
          ephemeral: true,
        });
      }
    });

    collector.on("end", async (collected) => {
      if (collected.size === 0) {
        let timeoutEmbed = client
          .embed()
          .setTitle("⏳ Time's Up!")
          .setDescription(
            `You didn't guess the correct flag in time. The correct flag was **${selectedFlag}**.`
          )
          .setColor("Orange");
        await message.edit({ embeds: [timeoutEmbed], components: [] });
      }
    });
  }
}

module.exports = Flags;
