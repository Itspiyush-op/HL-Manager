const { Commands, MainClient, Context } = require("../../Structures/index.js");
const { ApplicationCommandOptionType } = require("discord.js");


class Timeout extends Commands {
  constructor(client) {
    super(client, {
      name: "timeout",
      description: "Put a member in timeout.",
      usage: "timeout <@member | userID> <duration> [reason]",
      cooldown: 5,
      aliases: ["mute"],
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "member",
          description: "The member you want to timeout",
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: "duration",
          description: "Duration for the timeout (e.g., 1m, 1h, 1d)",
          type: ApplicationCommandOptionType.String,
          required: true,
        },
        {
          name: "reason",
          description: "Reason for the timeout",
          type: ApplicationCommandOptionType.String,
          required: false,
        },
      ],
      slashOnly: false,
      userPermissions: ["ModerateMembers"],
      botPermissions: ["ModerateMembers"],
    });
  }

  async execute(client, ctx, args) {
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    let member, duration, reason;

    if (ctx.isInteraction) {
      member = ctx.interaction.options.getMember("member");
      duration = ctx.interaction.options.getString("duration");
      reason =
        ctx.interaction.options.getString("reason") ||
        `Timeout by ${ctx.author.tag}`;
    } else {
      const targetId = args[0];
      duration = args[1];
      reason = args.slice(2).join(" ") || `Timeout by ${ctx.author.tag}`;
      member =
        ctx.message.mentions.members.first() ||
        (await ctx.guild.members.fetch(targetId).catch(() => null));
    }

    if (!member) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | Member not found! Please provide a valid mention or user ID.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    let usersArray = await client.db.getUserFromProtection(ctx.guild.id);
    if (usersArray.includes(member.user.id)) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | You are not allowed to timeout **${member.user.username}** due to protection settings.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    if (member.roles.highest.position >= ctx.member.roles.highest.position) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | You can't timeout someone with an equal or higher role!`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    if (!member.moderatable) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | I can't timeout this member due to role hierarchy.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    let timeoutDuration = this.parseDuration(duration);
    if (timeoutDuration === null) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | Please provide a valid duration (e.g., 1m, 1h, 1d).`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    let maxTimeout = 2419200000; 
    let minTimeout = 10000;

    if (timeoutDuration < minTimeout) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | The timeout duration must be at least 10 seconds.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    if (timeoutDuration > maxTimeout) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | The timeout duration cannot exceed 28 days.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    await member.timeout(timeoutDuration, reason).catch((err) => {
      embed
        .setDescription(
          `${client.config.emoji.cross} | An error occurred while trying to timeout the member.`
        )
        .setColor("Red");
      return ctx.sendMessage({ embeds: [embed] });
    });

    embed
      .setDescription(
        `${client.config.emoji.tick} | Successfully timed out **${member.user.tag}** for **${duration}** due to: **${reason}**`
      )
      .setColor("Green");
    await ctx.sendMessage({ embeds: [embed] });
    await member
      .send({
        embeds: [
          client
            .embed()
            .setAuthor({
              name: ctx.guild.name,
              iconURL: ctx.guild.iconURL({ dynamic: true }),
            })
            .setTitle("You have been put in timeout")
            .setDescription(
              `You have been put in timeout for **${duration}**.\n**Reason:** ${reason}`
            )
            .setColor("Yellow")
            .setTimestamp(),
        ],
      })
      .catch((_) => null);
  }

  parseDuration(duration) {
    const matches = duration.match(/^(\d+)([smhd]?)$/);
    if (!matches) return null;

    const value = parseInt(matches[1], 10);
    const unit = matches[2];

    switch (unit) {
      case "s":
        return value * 1000;
      case "m":
        return value * 60 * 1000;
      case "h":
        return value * 60 * 60 * 1000;
      case "d":
        return value * 24 * 60 * 60 * 1000;
      default:
        return value;
    }
  }
}

module.exports = Timeout;
