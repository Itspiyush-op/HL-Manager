const { ApplicationCommandOptionType } = require("discord.js");
const { Commands, Context, MainClient } = require("../../Structures/index.js");

class Whois extends Commands {
  constructor(client) {
    super(client, {
      name: "whois",
      description: "Get user information!",
      usage: "whois <@user>",
      cooldown: 10,
      aliases: ["ui", "user"],
      category: "General",
      args: false,
      slash: true,
      options: [
        {
          name: "user",
          description: "User to get information for",
          type: ApplicationCommandOptionType.User,
          required: false,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }

  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx, args) {
    let user;

    if (ctx.isInteraction) {
      user = ctx.interaction.options.getUser("user");
    } else {
      user =
        ctx.message.mentions.users.first() ||
        (await client.users.fetch(args[0]).catch((_) => null));
    }

    if (!user) user = ctx.author;

    const guildMember = await ctx.guild.members.cache.get(user.id);
    let description = `Mention: <@${user.id}>\nDisplay Name: ${
      guildMember ? guildMember.displayName : user.displayName
    }\nUsername: ${user.username}\nID: ${
      user.id
    }\nAvatar URL: [Download Link](https://discord.com/users/${user.id})`;

    const banner = await client.users
      .fetch(user.id, { force: true })
      .then((u) => u.bannerURL({ dynamic: true, size: 4096 }));

    if (banner) {
      description += `\nNitro Status: Yes, Nitro User!`;
    } else if (user.displayAvatarURL({ dynamic: true }).includes("gif")) {
      description += `\nNitro Status: Yes, Nitro User!`;
    } else {
      description += `\nNitro Status: No Nitro`;
    }

    description += `\nCreated At: <t:${Math.floor(
      user.createdTimestamp / 1000
    )}:F> (<t:${Math.floor(user.createdTimestamp / 1000)}:R>)`;

    if (guildMember) {
      description += `\nJoined Server: <t:${Math.floor(
        guildMember.joinedTimestamp / 1000
      )}:F> (<t:${Math.floor(guildMember.joinedTimestamp / 1000)}:R>)`;
    }

    let embed = client
      .embed()
      .setAuthor({
        name: ctx.author.displayName,
        iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
      })
      .setTitle(`${user.username}'s Info`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }) || null)
      .setDescription(description);

    if (banner) {
      embed.setImage(banner);
    }

    return ctx.sendMessage({ embeds: [embed] });
  }
}

module.exports = Whois;
