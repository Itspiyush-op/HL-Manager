const { Commands, MainClient, Context } = require("../../Structures/index.js");
const { ApplicationCommandOptionType } = require("discord.js");

class Ban extends Commands {
  constructor(client) {
    super(client, {
      name: "ban",
      description: "Ban a member from the server.",
      usage: "ban <@member | userID> [reason]",
      cooldown: 5,
      aliases: ["fuckyou"],
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "member",
          description: "The member you want to ban",
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: "reason",
          description: "Reason for banning the member",
          type: ApplicationCommandOptionType.String,
          required: false,
        },
      ],
      slashOnly: false,
      userPermissions: ["BanMembers"],
      botPermissions: ["BanMembers"],
    });
  }

  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */

  async execute(client, ctx, args) {
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    let member;
    let reason;

    if (ctx.isInteraction) {
      member = ctx.interaction.options.getMember("member");
      reason =
        ctx.interaction.options.getString("reason") ||
        `Banned by ${ctx.author.tag}`;
    } else {
      const targetId = args[0];
      reason = args.slice(1).join(" ") || `Banned by ${ctx.author.tag}`;
      member =
        ctx.message.mentions.members.first() ||
        (await ctx.guild.members.fetch(targetId).catch(() => null));
    }

    if (!member) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | Member not found! Please provide a valid mention or user ID.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    let usersArray = await client.db.getUserFromProtection(ctx.guild.id);
    if (usersArray.includes(member.user.id)) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | You are not allowed to ban **${member.user.username}** due to protection settings.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    if (member.roles.highest.position >= ctx.member.roles.highest.position) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | You can't ban someone with an equal or higher role!`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    if (!member.bannable) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | I can't ban this member due to role hierarchy.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    await member
      .send({
        embeds: [
          client
            .embed()
            .setAuthor({
              name: ctx.guild.name,
              iconURL: ctx.guild.iconURL({ dynamic: true }),
            })
            .setTitle("You have been banned from the server")
            .setDescription(
              `You have been banned from **${ctx.guild.name}**.\n**Reason:** ${reason}`
            )
            .setColor("Red")
            .setTimestamp(),
        ],
      })
      .catch((_) => null);
    await member.ban({ reason }).catch((err) => {
      embed
        .setDescription(
          `${client.config.emoji.cross} | An error occurred while trying to ban the member.`
        )
        .setColor("Red");
      return ctx.sendMessage({ embeds: [embed] });
    });

    embed
      .setDescription(
        `${client.config.emoji.tick} | Successfully banned **${member.user.tag}** for : **${reason}**`
      )
      .setColor("Green");
    await ctx.sendMessage({ embeds: [embed] });
  }
}

module.exports = Ban;
