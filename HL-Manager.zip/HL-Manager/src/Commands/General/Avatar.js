const { ApplicationCommandOptionType } = require("discord.js");
const { Commands, MainClient, Context } = require("../../Structures/index.js");

class Avatar extends Commands {
  constructor(client) {
    super(client, {
      name: "avatar",
      description: "Avatar subcommands!",
      usage: "avatar <user | guild> <@user>",
      cooldown: 10,
      aliases: ["av"],
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "user",
          description: "Gets a users default avatar",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "user",
              description: "User to fetch avatar from",
              type: ApplicationCommandOptionType.User,
              required: false,
            },
          ],
        },
        {
          name: "guild",
          description: "Gets users server avatar, if they have one",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "user",
              description: "User to fetch avatar from",
              type: ApplicationCommandOptionType.User,
              required: false,
            },
          ],
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }

  /**
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx, args) {
    let subCommands, user;

    if (ctx.isInteraction) {
      subCommands = ctx.interaction.options.getSubcommand();
      user = ctx.interaction.options.getUser("user") || ctx.author;
    } else {
      subCommands = args[0].toLowerCase();
      user =
        ctx.message.mentions.users.first() ||
        (await client.users.fetch(args[1]).catch((_) => null));
      if (!user) user = ctx.author;
    }

    let embed = client.embed().setAuthor({
      name: client.user.displayName,
      iconURL: client.user.displayAvatarURL({ dynamic: true }),
    });

    switch (subCommands) {
      case "user":
        embed
          .setDescription(
            `[Avatar URL](${user.displayAvatarURL({
              dynamic: true,
              size: 4096,
            })})`
          )
          .setImage(
            user.displayAvatarURL({ dynamic: true, size: 4096 }) || null
          )
          .setFooter({
            text: `Requested by ${ctx.author.displayName} | Dev: @${client.config.devName}`,
            iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
          });
        await ctx.sendMessage({ embeds: [embed] });
        break;
      case "guild":
        user = await ctx.guild.members.cache
          .get(user.id || ctx.author.id)
          
        if (user) {
          embed
            .setDescription(
              `[Avatar URL](${user.displayAvatarURL({
                dynamic: true,
                size: 4096,
              })})`
            )
            .setImage(user.displayAvatarURL({ dynamic: true, size: 4096 }));
          await ctx.sendMessage({ embeds: [embed] });
        }
        break;
      default:
        embed
          .setColor("Red")
          .setDescription(
            `${client.config.emoji.cross} | Wrong **Sub Commands** provided!`
          );
        await ctx.sendMessage({ embeds: [embed], ephemeral: true });
        break;
    }
  }
}

module.exports = Avatar;
