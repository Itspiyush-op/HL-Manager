const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { MainClient, Context, Commands } = require("../../Structures/index.js");

class Help extends Commands {
  constructor(client) {
    super(client, {
      name: "help",
      description: "Display a list of available commands!",
      usage: "help",
      aliases: ["h"],
      cooldown: 10,
      category: "General",
      args: false,
      slash: true,
      options: [],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }

  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx) {
    const commands = client.commandsArray;
    this.commandsArray = [];

    this.page = 1;
    this.perPage = 10;

    commands.forEach((command) => this.pushCommands(command));
    this.totalPages = Math.ceil(this.commandsArray.length / this.perPage);

    const msg = await ctx.sendMessage({
      embeds: [this.embedFunction(this.page)],
      components: [this.rowFunction(this.page)],
    });

    const collector = msg.createMessageComponentCollector({ time: 60000 });

    collector.on("collect", async (i) => {
      if (ctx.author.id !== i.user.id)
        return await i.reply({
          content: `${client.config.emoji.cross} **|** You cannot use this button`,
          ephemeral: true,
        });

      if (i.customId === "back") this.page--;
      if (i.customId === "next") this.page++;

      await i.update({
        embeds: [this.embedFunction(this.page)],
        components: [this.rowFunction(this.page)],
      });
    });

    collector.on("end", async () => {
      await msg.edit({ components: [] });
      return collector.stop();
    });
  }
  pushCommands(command, prefix = "/") {
    if (
      command.options &&
      Array.isArray(command.options) &&
      command.options.some((opt) => opt.type === 1)
    ) {
      command.hasSubcommands = true;
    } else {
      this.commandsArray.push({
        name: `${prefix}${command.name}`,
        description: command.description || "No Description Provided!",
      });
    }

    if (
      command.options &&
      Array.isArray(command.options) &&
      command.options.length > 0
    ) {
      command.options.forEach((subCommand) => {
        if (subCommand.type === 1)
          this.pushCommands(subCommand, `${prefix}${command.name} `);
      });
    }
  }

  embedFunction(page) {
    let startIndex = (page - 1) * this.perPage;
    let endIndex = startIndex + this.perPage;
    let pageCommands = this.commandsArray.slice(startIndex, endIndex);
    let description = pageCommands.length
      ? pageCommands
          .map((cmd) => `**${cmd.name}** - ${cmd.description}`)
          .join("\n")
      : "Commands Not Found!";

    return this.client
      .embed()
      .setAuthor({
        name: this.client.user.displayName,
        iconURL: this.client.user.displayAvatarURL({ dynamic: true }),
      })
      .setColor(this.client.config.embedColor)
      .setTitle("Available Commands")
      .setDescription(description)
      .setFooter({
        text: `Page: ${page} of ${this.totalPages} | Dev: @${this.client.config.devName}`,
      });
  }

  rowFunction(page) {
    return new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("back")
        .setLabel("<")
        .setStyle(ButtonStyle.Primary)
        .setDisabled(page === 1),

      new ButtonBuilder()
        .setCustomId("next")
        .setLabel(">")
        .setStyle(ButtonStyle.Primary)
        .setDisabled(page === this.totalPages)
    );
  }
}

module.exports = Help;
