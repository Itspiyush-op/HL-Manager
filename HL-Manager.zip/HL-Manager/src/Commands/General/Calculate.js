const math = require("mathjs");
const { ApplicationCommandOptionType } = require("discord.js");
const { Commands, Context, MainClient } = require("../../Structures/index.js");

class Calculate extends Commands {
  constructor(client) {
    super(client, {
      name: "calculate",
      description: "Calculate a mathematical expression!",
      usage: "calculate <expression>",
      cooldown: 5,
      aliases: ["cal", "calc"],
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "expression",
          description: "Provide a mathematical expression ( Ex: 2+2 )",
          type: ApplicationCommandOptionType.String,
          required: true,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }

  /**
   * @param { MainClient } client
   * @param { Context } ctx
  
   */

  async execute(client, ctx, args) {
    let expression;

    if (ctx.isInteraction) {
      expression = ctx.interaction.options.getString("expression");
    } else {
      expression = args.join(" ");
    }
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });
    try {
      let result = math.evaluate(expression);
      await ctx.sendMessage({
        embeds: [
          embed
            .setTitle("Calculation Result")
            .setDescription(`**${expression} = ${result}**`),
        ],
      });
    } catch (error) {
      await ctx.sendMessage({
        embeds: [
          embed
            .setColor("Red")
            .setDescription(
              `${client.config.emoji.cross} | Unable to calculate the given expression. Please check the syntax and try again.`
            ),
        ],
      });
    }
  }
}

module.exports = Calculate;
