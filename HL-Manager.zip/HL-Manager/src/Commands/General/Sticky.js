const { Commands, MainClient, Context } = require("../../Structures/index.js");
const { ApplicationCommandOptionType, ChannelType } = require("discord.js");

class Sticky extends Commands {
  constructor(client) {
    super(client, {
      name: "sticky",
      description: "Manage sticky messages",
      usage: "sticky <set | reset> <message> [#channel]",
      cooldown: 10,
      aliases: [],
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "set",
          description: "Set a sticky message for the channel",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "message",
              description: "The message to be sticky",
              type: ApplicationCommandOptionType.String,
              required: true,
            },
            {
              name: "channel",
              description:
                "The channel to set the sticky message in (defaults to the current channel)",
              type: ApplicationCommandOptionType.Channel,
              required: false,
              channel_types: [ChannelType.GuildText],
            },
          ],
        },
        {
          name: "reset",
          description: "Remove the sticky message from the channel",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "channel",
              description: "Target channel (default: current)",
              type: ApplicationCommandOptionType.Channel,
              required: false,
            },
          ],
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: ["Administrator"],
      botPermissions: [],
    });
  }

  /**
   *
   * @param {MainClient} client
   * @param {Context} ctx
   */
  async execute(client, ctx, args) {
    let subCommands, message, channel;
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });
    if (ctx.isInteraction) {
      subCommands = ctx.interaction.options.getSubcommand();
      message = ctx.interaction.options.getString("message");
      channel = ctx.interaction.options.getChannel("channel") || ctx.channel;
    } else {
      subCommands = args[0] ? args[0].toLowerCase() : null;
      message = args[1];
      channel =
        ctx.message.mentions.channels.first() ||
        ctx.guild.channels.cache.get(args[2]);
    }

    if (!channel) {
      channel = ctx.channel;
    }

    switch (subCommands) {
      case "set":
        if (!message) {
          return await ctx.sendMessage({
            embeds: [
              embed
                .setColor("Red")
                .setDescription(
                  `${client.config.emoji.cross} | Please provide sticky message!`
                ),
            ],
          });
        }
        let m = await channel.send({
          content: message,
          allowedMentions: { parse: [] },
        });
        await client.db.setSticky(channel.id, message, m.id);
        await ctx.sendMessage({
          embeds: [
            embed.setDescription(
              `${client.config.emoji.tick} | Sticky message successfully set!`
            ),
          ],
        });
        break;
      case "reset":
        await client.db.deleteSticky(channel.id);
        await ctx.sendMessage({
          embeds: [
            embed.setDescription(
              `${client.config.emoji.tick} | Sticky message successfully reset!`
            ),
          ],
        });
        return;
      default:
        await ctx.sendMessage({
          embeds: [
            embed
              .setDescription(
                `${client.config.emoji.cross} | An unexpected error occurred. Please try again.`
              )
              .setColor("Red"),
          ],
        });
        break;
    }
  }
}

module.exports = Sticky;
