const { Commands, MainClient, Context } = require("../../Structures/index.js");

class Ping extends Commands {
  constructor(client) {
    super(client, {
      name: "ping",
      description: "Shows the bot's latency!",
      usage: "ping",
      cooldown: 10,
      aliases: ["pong"],
      category: "General",
      args: false,
      slash: true,
      options: [],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }
  /**
   *
   * @param { MainClient} client
   * @param { Context } ctx
   */
  async execute(client, ctx) {
    await ctx.sendMessage("🏓 Pong!");
    let ping = Math.floor(Date.now() - ctx.createdTimestamp);
    await ctx.editMessage(
      `🏓 WS: ${Math.floor(client.ws.ping)}ms  |  API: ${ping}ms`
    );
  }
}

module.exports = Ping;
