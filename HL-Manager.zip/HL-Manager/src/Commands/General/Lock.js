const { Commands, MainClient, Context } = require("../../Structures/index.js");
const { PermissionFlagsBits } = require("discord.js");

class Lock extends Commands {
  constructor(client) {
    super(client, {
      name: "lock",
      description:
        "Prevents everyone from sending messages in the current channel.",
      usage: "lock",
      cooldown: 10,
      aliases: [],
      category: "General",
      args: false,
      slash: false,
      options: [],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: ["ManageChannels"],
    });
  }

  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */

  async execute(client, ctx) {
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    if (
      !ctx.channel
        .permissionsFor(ctx.member)
        .has(PermissionFlagsBits.ManageChannels)
    ) {
      return await ctx.sendMessage({
        embeds: [
          embed
            .setColor("Red")
            .setDescription(
              `${client.config.emoji.cross} | You don't have **ManageChannels** permission!`
            ),
        ],
      });
    }
    let everyone = ctx.guild.roles.everyone;

    await ctx.channel.permissionOverwrites
      .edit(everyone, { SendMessages: false })
      .then(() => {
        embed.setDescription(
          `${client.config.emoji.tick} | This channel has been locked. No one can send messages now.`
        );

        ctx.sendMessage({ embeds: [embed] });
      })
      .catch((err) => {
        embed
          .setDescription(
            `${client.config.emoji.cross} | An error occurred while trying to lock the channel.`
          )
          .setColor("Red");
        ctx.sendMessage({ embeds: [embed] });
      });
  }
}

module.exports = Lock;
