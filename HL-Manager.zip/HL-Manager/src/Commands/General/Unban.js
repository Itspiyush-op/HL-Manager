const { Commands, MainClient, Context } = require("../../Structures/index.js");
const { ApplicationCommandOptionType } = require("discord.js");

class Unban extends Commands {
  constructor(client) {
    super(client, {
      name: "unban",
      description: "Unban a member from the server.",
      usage: "unban <userID | username>",
      cooldown: 5,
      aliases: [],
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "user",
          description: "The user ID or username of the member to unban",
          type: ApplicationCommandOptionType.String,
          required: true,
        },
      ],
      slashOnly: false,
      userPermissions: ["BanMembers"],
      botPermissions: ["BanMembers"],
    });
  }

  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */

  async execute(client, ctx, args) {
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    let userID = ctx.isInteraction
      ? ctx.interaction.options.getString("user")
      : args[0];

    if (!/^\d+$/.test(userID)) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | Please provide a valid user ID.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    const bans = await ctx.guild.bans.fetch().catch(() => []);
    const bannedUser = bans.get(userID);

    if (!bannedUser) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | This user is not banned.`
        )
        .setColor("Red");
      return await ctx.sendMessage({ embeds: [embed] });
    }

    await ctx.guild.bans
      .remove(userID)
      .then(() => {
        embed
          .setDescription(
            `${client.config.emoji.tick} | Successfully unbanned **${bannedUser.user.tag}**`
          )
          .setColor("Green");
        return ctx.sendMessage({ embeds: [embed] });
      })
      .catch((err) => {
        embed
          .setDescription(
            `${client.config.emoji.cross} | An error occurred while trying to unban the member.`
          )
          .setColor("Red");
        return ctx.sendMessage({ embeds: [embed] });
      });
  }
}

module.exports = Unban;
