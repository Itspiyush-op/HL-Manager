class Events {
  constructor(client, file, options) {
    this.client = client;
    this.file = file;
    this.name = options.name;
    this.once = options.once || false;
    this.fileName = file.split(".")[0];
  }

  async execute(..._args) {
    return await Promise.resolve();
  }
}

module.exports = Events;
