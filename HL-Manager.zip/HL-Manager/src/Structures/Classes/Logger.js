class Logger {
  error(message) {
    return console.log("\x1b[1m\x1b[35m%s\x1b[0m", `[CLIENT]: ${message}`);
  }
  success(message) {
    return console.log("\x1b[1m\x1b[32m%s\x1b[0m", `[SUCCESS]: ${message}`);
  }
  warn(message) {
    return console.log("\x1b[1m\x1b[33m%s\x1b[0m", `[WARN]: ${message}`);
  }
  info(message) {
    return console.log("\x1b[1m\x1b[34m%s\x1b[0m", `[INFO]: ${message}`);
  }
  login(message) {
    return console.log("\x1b[1m\x1b[35m%s\x1b[0m", `[LOGIN]: ${message}`);
  }
}

module.exports = Logger;
