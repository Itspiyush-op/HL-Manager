
const { MainClient } = require("../Structures/index.js");
const { Message } = require("discord.js");

/**
 *
 * @param { MainClient } client
 * @param { Message } message
 */

module.exports = async (client, message) => {
  if (message.author.bot) return;
  if (message.channel.type === "DM") return;

  let data = await client.db.getLottery(message.guild.id);
  if (!data) return;

  let lotteryChannelId = data ? data.channelId : null;
  let lotteryRoleId = data ? data.roleId : null;
  let lotteryTrigger = data ? parseInt(data.trigger, 10) : null;
  if (message.channel.id !== lotteryChannelId) return;

  let content = message.content.toLowerCase();
  let words = content.split(/\s+/);
  let numericValues = words
    .map((word) => {
      if (/^0x[0-9a-f]+$/i.test(word)) {
        return parseInt(word, 16);
      }

      if (!isNaN(word)) {
        return parseFloat(word);
      }
      return null;
    })
    .filter((value) => value !== null);

  let validNumber = numericValues.some((num) => num >= lotteryTrigger);

  if (validNumber) {
    try {
      let role = message.guild.roles.cache.get(lotteryRoleId);
      if (message.guild.members.me.roles.highest <= role.position) {
        return message.react("😭");
      }
      await message.member.roles.add(role);
      return message.react("✅");
    } catch (error) {
      message.react("⚰️");
      console.error(error);
    }
  } else {
    return message.react("❌");
  }
};
