const { Schema, model } = require("mongoose");

const badgeSchema = new Schema({
  userId: { type: String, required: true, unique: true },
  badges: [{ type: String, default: [], required: true }],
});

module.exports = model("Badges", badgeSchema);
