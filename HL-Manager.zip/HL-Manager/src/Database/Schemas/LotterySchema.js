const { Schema, model } = require("mongoose");

const lotterySchema = new Schema({
  guildId: {
    type: String,
    required: true,
    unique: true,
  },
  trigger: {
    type: Number,
    required: true,
  },
  roleId: {
    type: String,
    required: true,
  },
  channelId: {
    type: String,
    required: true,
  },
});

module.exports = model("AutoLotteryAccess", lotterySchema);
