const prefixData = require("./Schemas/PrefixSchema.js");
const config = require("../../config.json");
const lotteryData = require("./Schemas/LotterySchema.js");
const stickyData = require("./Schemas/StickySchema.js");
const protectionData = require("./Schemas/ProtectionSchema.js");
const badgeData = require("./Schemas/BadgeSchema.js");

class Database {
  async setPrefix(guildId, newPrefix) {
    let data = await prefixData.findOne({ guildId });
    if (!data) {
      data = new prefixData({
        guildId: guildId,
        prefix: newPrefix,
      });
      await data.save();
    } else {
      data.prefix = newPrefix;
      await data.save();
    }
  }

  async getPrefix(guildId) {
    let data = await prefixData.findOne({ guildId });
    if (!data) {
      data = new prefixData({
        guildId: guildId,
        prefix: config.prefix,
      });
      await data.save();
      return config.prefix;
    } else {
      return data ? data.prefix : null;
    }
  }

  async setLottery(guildId, trigger, roleId, channelId) {
    let data = await lotteryData.findOne({ guildId });
    if (!data) {
      data = new lotteryData({
        guildId: guildId,
        trigger: trigger,
        roleId: roleId,
        channelId: channelId,
      });
      await data.save();
    } else {
      data.trigger = trigger;
      data.roleId = roleId;
      data.channelId = channelId;
      await data.save();
    }
  }

  async getLottery(guildId) {
    let data = await lotteryData.findOne({ guildId });
    if (!data) {
      return null;
    } else {
      return data;
    }
  }

  async deleteLottery(guildId) {
    let result = await lotteryData.deleteOne({ guildId });
    return result.deletedCount > 0;
  }

  async setSticky(channelId, message, oldMessageId) {
    let data = await stickyData.findOne({ channelId });
    if (!data) {
      data = new stickyData({
        channelId: channelId,
        oldMessageId: oldMessageId,
        message: message,
      });
      await data.save();
    } else {
      data.message = message;
      data.oldMessageId = oldMessageId;
      await data.save();
    }
  }

  async deleteSticky(channelId) {
    let result = await stickyData.deleteOne({ channelId });
    return result.deletedCount > 0;
  }

  async getSticky(channelId) {
    let data = await stickyData.findOne({ channelId });
    return data;
  }

  async addUserToProtection(guildId, userId) {
    let data = await protectionData.findOne({ guildId });
    if (!data) {
      data = new protectionData({
        guildId: guildId,
        usersArray: [userId],
      });
      await data.save();
    } else {
      if (!data.usersArray.includes(userId)) {
        data.usersArray.push(userId);
        await data.save();
      }
    }
  }

  async getUserFromProtection(guildId) {
    let data = await protectionData.findOne({ guildId });
    if (data) {
      return data ? data.usersArray : null;
    }
    return [];
  }

  async removeUserFromProtection(guildId, userId) {
    let data = await protectionData.findOne({ guildId });
    if (data) {
      data.usersArray = data.usersArray.filter((user) => user !== userId);
      await data.save();
    }
  }

  async removeAllUsersFromProtection(guildId) {
    let result = await protectionData.deleteOne({ guildId });
    return result.deletedCount > 0;
  }

  async addBadge(userId, badge) {
    let data = await badgeData.findOne({ userId });
    if (!data) {
      data = new badgeData({
        userId: userId,
        badges: [badge],
      });
      await data.save();
    } else {
      if (!data.badges.includes(badge)) {
        data.badges.push(badge);
        await data.save();
      }
    }
  }

  async getBadges(userId) {
    let data = await badgeData.findOne({ userId });
    if (data) {
      return data ? data.badges : null;
    }
    return [config.badges.member];
  }

  async removeBadge(userId, badge) {
    let data = await badgeData.findOne({ userId });
    if (data) {
      data.badges = data.badges.filter((b) => b !== badge);
      await data.save();
    }
  }

  async removeAllBadges(userId) {
    let result = await badgeData.deleteOne({ userId });
    return result.deletedCount > 0;
  }
}

module.exports = Database;
