const { Events, MainClient, Context } = require("../../Structures/index.js");
const { Message, PermissionFlagsBits } = require("discord.js");
const lotterySetup = require("../../Functions/Lottery.js");
const stickySetup = require("../../Functions/Sticky.js");

class MessageCreate extends Events {
  constructor(client, file) {
    super(client, file, {
      name: "messageCreate",
      once: false,
    });
  }

  /**
   * @param { Message } message
   * @param { MainClient } client
   */
  async execute(message, client) {
    (async (client, message) => {
      await stickySetup(client, message);
      await lotterySetup(client, message);
    })(client, message);

    if (message.author.bot) return;
    let prefix = (await client.db.getPrefix(message.guild.id)) || client.prefix;
    if (!message.content.startsWith(prefix)) return;
    if (message.channel.type === "DM") return;

    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();

    const command =
      client.commands.get(cmd) || client.commands.get(client.aliases.get(cmd));
    if (!command) return;

    const ctx = new Context(message, args);
    ctx.setArgs(args);

    let embed = client
      .embed()
      .setColor("Red")
      .setAuthor({
        name: message.author.displayName,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      });

    if (
      !message.inGuild() ||
      !message.channel
        .permissionsFor(message.guild.members.me)
        .has(PermissionFlagsBits.ViewChannel)
    )
      return;

    if (
      !message.channel
        .permissionsFor(message.guild.members.me)
        .has(PermissionFlagsBits.SendMessages)
    )
      return await message.author
        .send({
          embeds: [
            embed.setDescription(
              `\`❌\` | I Don't Have **SendMessages** Permission In <#${message.channel.id}>! `
            ),
          ],
        })
        .catch((_) => null);

    if (
      !message.channel
        .permissionsFor(message.guild.members.me)
        .has(PermissionFlagsBits.EmbedLinks)
    )
      return (
        await message.author.send({
          embeds: [
            embed.setDescription(
              `\`❌\` | I Don't Have **EmbedLinks** Permission!`
            ),
          ],
        })
      ).catch((_) => null);

    const cooldown = client.cooldowns.get(
      `${command.name}-${message.author.id}`
    );

    if (command.cooldown && cooldown) {
      if (Date.now() < cooldown) {
        let remainingTime = cooldown - Date.now();
        return await message.channel
          .send({
            embeds: [
              embed
                .setDescription(
                  `**⏱ | ${
                    message.member.displayName
                  }!** Slow down and try the command again **<t:${Math.floor(
                    (Date.now() + cooldown - Date.now()) / 1000
                  )}:R>**`
                )
                .setColor(client.config.embedColor),
            ],
          })
          .then((m) =>
            setTimeout(
              async () => await m.delete().catch((_) => null),
              remainingTime
            )
          );
      }
      client.cooldowns.set(
        `${command.name}-${message.author.id}`,
        Date.now() + command.cooldown * 1000
      );
      setTimeout(
        () => client.cooldowns.delete(`${command.name}-${message.author.id}`),
        command.cooldown * 1000
      );
    } else if (command.cooldown && !cooldown) {
      client.cooldowns.set(
        `${command.name}-${message.author.id}`,
        Date.now() + command.cooldown * 1000
      );
    }

    if (command.botPermissions) {
      let missingPerms = [];
      command.botPermissions.forEach((perm) => {
        if (
          !message.guild.members.me.permissions.has(perm) &&
          !message.channel.permissionsFor(message.guild.members.me).has(perm)
        ) {
          missingPerms.push(perm);
        }
      });

      if (missingPerms.length)
        return await message.channel
          .send({
            embeds: [
              embed.setDescription(
                `\`❌\` | I Don't Have **${missingPerms.join(
                  ", "
                )}** Permissions!`
              ),
            ],
          })
          .then((m) =>
            setTimeout(async () => await m.delete().catch((_) => null), 10000)
          );
    }

    if (command.userPermissions) {
      let missingPerms = [];
      command.userPermissions.forEach((perm) => {
        if (!message.member.permissions.has(perm)) {
          missingPerms.push(perm);
        }
      });
      if (missingPerms.length) {
        return await message.channel
          .send({
            embeds: [
              embed.setDescription(
                `\`❌\` | You Don't Have **${missingPerms.join(
                  ", "
                )}** Permissions!`
              ),
            ],
          })
          .then((m) =>
            setTimeout(async () => await m.delete().catch((_) => null), 10000)
          );
      }
    }

    if (
      command.devOnly === true &&
      !client.config.dev.includes(message.author.id)
    ) {
      return await message.channel
        .send({
          embeds: [
            embed.setDescription(
              `\`❌\` | This command is only for the developer of the bot!`
            ),
          ],
        })
        .then((m) =>
          setTimeout(async () => await m.delete().catch((_) => null), 10000)
        );
    }

    if (command.slashOnly && command.slashOnly === true) {
      return await message.channel
        .send({
          embeds: [
            embed.setDescription(
              `\`❌\` | Hey! It's a slash only command. Use \`/${command.name}\` instead.`
            ),
          ],
        })
        .then((m) =>
          setTimeout(async () => await m.delete().catch((_) => null), 10000)
        );
    }

    if (command.args && command.args === true) {
      if (!args.length) {
        embed
          .setTitle("Wrong Arguments!")
          .setDescription(`\`\`\`ymal\n${prefix + command.usage}\n\`\`\``);
        await message.channel
          .send({ embeds: [embed] })
          .then((m) =>
            setTimeout(async () => await m.delete().catch((_) => null), 10000)
          );
        return;
      }
    }

    try {
      return await command.execute(client, ctx, ctx.args);
    } catch (error) {
      console.error(error);
    }
  }
}

module.exports = MessageCreate;
