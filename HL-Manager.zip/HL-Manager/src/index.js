require("dotenv").config();
const { GatewayIntentBits, Partials } = require("discord.js");
const { MainClient } = require("./Structures/index.js");
const config = require("../config.json");

const options = {
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [
    Partials.User,
    Partials.Channel,
    Partials.Message,
    Partials.Reaction,
  ],
  allowedMentions: {
    parse: ["users"],
    repliedUser: false,
  },
};

const client = new MainClient(options);
client.start(config.token || process.env.TOKEN);

module.exports = client;
